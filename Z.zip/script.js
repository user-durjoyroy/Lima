function generateImage() {
  const text = document.getElementById("textInput").value;
  const encoded = encodeURIComponent(text);
  const imgUrl = `https://dummyimage.com/600x400/000/fff&text=${encoded}`;
  document.getElementById("outputImage").src = imgUrl;
}